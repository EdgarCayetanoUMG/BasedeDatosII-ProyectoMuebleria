const express = require('express');
const router = express.Router();

// Controllers
const tipoMov    = require('../controllers/tipoMovimientoController');
const centro     = require('../controllers/centroTrabajoController');
const listaMat   = require('../controllers/listaMaterialesController');
const bomDet     = require('../controllers/bomDetalleController');
const ordenProd  = require('../controllers/ordenProduccionController');
const movInv     = require('../controllers/movimientoInventarioController');
const consumo    = require('../controllers/consumoMateriaPrimaController');

// ── TIPO_MOVIMIENTO ──────────────────────────────────────────
router.get   ('/tipo-movimiento',      tipoMov.getAll);
router.get   ('/tipo-movimiento/:id',  tipoMov.getById);
router.post  ('/tipo-movimiento',      tipoMov.create);
router.put   ('/tipo-movimiento/:id',  tipoMov.update);
router.delete('/tipo-movimiento/:id',  tipoMov.remove);

// ── CENTRO_TRABAJO ───────────────────────────────────────────
router.get   ('/centro-trabajo',       centro.getAll);
router.get   ('/centro-trabajo/:id',   centro.getById);
router.post  ('/centro-trabajo',       centro.create);
router.put   ('/centro-trabajo/:id',   centro.update);
router.delete('/centro-trabajo/:id',   centro.remove);

// ── LISTA_MATERIALES ─────────────────────────────────────────
router.get   ('/lista-materiales',       listaMat.getAll);
router.get   ('/lista-materiales/:id',   listaMat.getById);
router.post  ('/lista-materiales',       listaMat.create);
router.put   ('/lista-materiales/:id',   listaMat.update);
router.delete('/lista-materiales/:id',   listaMat.remove);

// ── BOM_DETALLE ──────────────────────────────────────────────
router.get   ('/bom-detalle',                         bomDet.getAll);
router.get   ('/bom-detalle/:id',                     bomDet.getById);
router.get   ('/bom-detalle/por-lista/:id_lista',     bomDet.getByLista);
router.post  ('/bom-detalle',                         bomDet.create);
router.put   ('/bom-detalle/:id',                     bomDet.update);
router.delete('/bom-detalle/:id',                     bomDet.remove);

// ── ORDEN_PRODUCCION ─────────────────────────────────────────
router.get   ('/orden-produccion',       ordenProd.getAll);
router.get   ('/orden-produccion/:id',   ordenProd.getById);
router.post  ('/orden-produccion',       ordenProd.create);
router.put   ('/orden-produccion/:id',   ordenProd.update);
router.delete('/orden-produccion/:id',   ordenProd.remove);

// ── MOVIMIENTO_INVENTARIO ────────────────────────────────────
router.get   ('/movimiento-inventario',                            movInv.getAll);
router.get   ('/movimiento-inventario/:id',                        movInv.getById);
router.get   ('/movimiento-inventario/por-articulo/:cod_articulo', movInv.getByArticulo);
router.post  ('/movimiento-inventario',                            movInv.create);
router.put   ('/movimiento-inventario/:id',                        movInv.update);
router.delete('/movimiento-inventario/:id',                        movInv.remove);

// ── CONSUMO_MATERIA_PRIMA ────────────────────────────────────
router.get   ('/consumo-materia-prima',                        consumo.getAll);
router.get   ('/consumo-materia-prima/:id',                    consumo.getById);
router.get   ('/consumo-materia-prima/por-orden/:id_orden',    consumo.getByOrden);
router.post  ('/consumo-materia-prima',                        consumo.create);
router.put   ('/consumo-materia-prima/:id',                    consumo.update);
router.delete('/consumo-materia-prima/:id',                    consumo.remove);

module.exports = router;
