const { getConnection, closeConnection } = require('../config/db');

// GET ALL
const getAll = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT ID_TIPO_MOV, CODIGO, DESCRIPCION, NATURALEZA, ACTIVO,
              TO_CHAR(FECHA_CREACION,'YYYY-MM-DD') AS FECHA_CREACION
       FROM TIPO_MOVIMIENTO ORDER BY ID_TIPO_MOV`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

// GET BY ID
const getById = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT ID_TIPO_MOV, CODIGO, DESCRIPCION, NATURALEZA, ACTIVO,
              TO_CHAR(FECHA_CREACION,'YYYY-MM-DD') AS FECHA_CREACION
       FROM TIPO_MOVIMIENTO WHERE ID_TIPO_MOV = :id`,
      [req.params.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Registro no encontrado' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

// CREATE
const create = async (req, res) => {
  let conn;
  const { codigo, descripcion, naturaleza, activo = 1 } = req.body;
  if (!codigo || !descripcion || !naturaleza)
    return res.status(400).json({ success: false, message: 'codigo, descripcion y naturaleza son requeridos' });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO TIPO_MOVIMIENTO (CODIGO, DESCRIPCION, NATURALEZA, ACTIVO)
       VALUES (:codigo, :descripcion, :naturaleza, :activo)
       RETURNING ID_TIPO_MOV INTO :id`,
      {
        codigo, descripcion, naturaleza: naturaleza.toUpperCase(), activo,
        id: { dir: require('oracledb').BIND_OUT, type: require('oracledb').NUMBER }
      }
    );
    res.status(201).json({ success: true, message: 'Tipo de movimiento creado', id: result.outBinds.id[0] });
  } catch (err) {
    if (err.errorNum === 1)
      return res.status(409).json({ success: false, message: 'El código ya existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

// UPDATE
const update = async (req, res) => {
  let conn;
  const { descripcion, naturaleza, activo } = req.body;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `UPDATE TIPO_MOVIMIENTO
       SET DESCRIPCION = NVL(:descripcion, DESCRIPCION),
           NATURALEZA  = NVL(:naturaleza, NATURALEZA),
           ACTIVO      = NVL(:activo, ACTIVO)
       WHERE ID_TIPO_MOV = :id`,
      { descripcion, naturaleza, activo, id: req.params.id }
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Registro no encontrado' });
    res.json({ success: true, message: 'Tipo de movimiento actualizado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

// DELETE
const remove = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `DELETE FROM TIPO_MOVIMIENTO WHERE ID_TIPO_MOV = :id`,
      [req.params.id]
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Registro no encontrado' });
    res.json({ success: true, message: 'Tipo de movimiento eliminado' });
  } catch (err) {
    if (err.errorNum === 2292)
      return res.status(409).json({ success: false, message: 'No se puede eliminar: tiene registros relacionados' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

module.exports = { getAll, getById, create, update, remove };
