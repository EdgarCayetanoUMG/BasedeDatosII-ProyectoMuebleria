const { getConnection, closeConnection } = require('../config/db');
const oracledb = require('oracledb');

const getAll = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT OP.ID_ORDEN, OP.NUMERO_ORDEN, OP.ESTADO,
              OP.ID_LISTA, LM.DESCRIPCION AS LISTA_MATERIALES,
              OP.ID_CENTRO, CT.NOMBRE AS CENTRO_TRABAJO,
              TO_CHAR(OP.FECHA_EMISION,'YYYY-MM-DD') AS FECHA_EMISION,
              TO_CHAR(OP.FECHA_INICIO,'YYYY-MM-DD')  AS FECHA_INICIO,
              TO_CHAR(OP.FECHA_FIN,'YYYY-MM-DD')     AS FECHA_FIN,
              OP.CANTIDAD_PLANIF, OP.CANTIDAD_REAL, OP.OBSERVACIONES
       FROM ORDEN_PRODUCCION OP
       JOIN LISTA_MATERIALES LM ON LM.ID_LISTA = OP.ID_LISTA
       JOIN CENTRO_TRABAJO   CT ON CT.ID_CENTRO = OP.ID_CENTRO
       ORDER BY OP.ID_ORDEN DESC`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const getById = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT OP.ID_ORDEN, OP.NUMERO_ORDEN, OP.ESTADO,
              OP.ID_LISTA, LM.DESCRIPCION AS LISTA_MATERIALES,
              OP.ID_CENTRO, CT.NOMBRE AS CENTRO_TRABAJO,
              TO_CHAR(OP.FECHA_EMISION,'YYYY-MM-DD') AS FECHA_EMISION,
              TO_CHAR(OP.FECHA_INICIO,'YYYY-MM-DD')  AS FECHA_INICIO,
              TO_CHAR(OP.FECHA_FIN,'YYYY-MM-DD')     AS FECHA_FIN,
              OP.CANTIDAD_PLANIF, OP.CANTIDAD_REAL, OP.OBSERVACIONES
       FROM ORDEN_PRODUCCION OP
       JOIN LISTA_MATERIALES LM ON LM.ID_LISTA = OP.ID_LISTA
       JOIN CENTRO_TRABAJO   CT ON CT.ID_CENTRO = OP.ID_CENTRO
       WHERE OP.ID_ORDEN = :id`,
      [req.params.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Orden de producción no encontrada' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const create = async (req, res) => {
  let conn;
  const { numero_orden, id_lista, id_centro, fecha_inicio, fecha_fin, cantidad_planif, observaciones } = req.body;
  if (!numero_orden || !id_lista || !id_centro || !cantidad_planif)
    return res.status(400).json({ success: false, message: 'numero_orden, id_lista, id_centro y cantidad_planif son requeridos' });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO ORDEN_PRODUCCION
         (NUMERO_ORDEN, ID_LISTA, ID_CENTRO, FECHA_INICIO, FECHA_FIN, CANTIDAD_PLANIF, OBSERVACIONES)
       VALUES
         (:numero_orden, :id_lista, :id_centro,
          TO_DATE(:fecha_inicio,'YYYY-MM-DD'), TO_DATE(:fecha_fin,'YYYY-MM-DD'),
          :cantidad_planif, :observaciones)
       RETURNING ID_ORDEN INTO :id`,
      {
        numero_orden, id_lista, id_centro,
        fecha_inicio: fecha_inicio || null,
        fecha_fin: fecha_fin || null,
        cantidad_planif,
        observaciones: observaciones || null,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }
    );
    res.status(201).json({ success: true, message: 'Orden de producción creada', id: result.outBinds.id[0] });
  } catch (err) {
    if (err.errorNum === 1)
      return res.status(409).json({ success: false, message: 'El número de orden ya existe' });
    if (err.errorNum === 2291)
      return res.status(400).json({ success: false, message: 'Lista de materiales o centro de trabajo no existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const update = async (req, res) => {
  let conn;
  const { estado, fecha_inicio, fecha_fin, cantidad_real, observaciones } = req.body;
  const estadosValidos = ['PENDIENTE','EN_PROCESO','COMPLETADA','CANCELADA'];
  if (estado && !estadosValidos.includes(estado))
    return res.status(400).json({ success: false, message: `Estado inválido. Válidos: ${estadosValidos.join(', ')}` });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `UPDATE ORDEN_PRODUCCION
       SET ESTADO        = NVL(:estado, ESTADO),
           FECHA_INICIO  = NVL(TO_DATE(:fecha_inicio,'YYYY-MM-DD'), FECHA_INICIO),
           FECHA_FIN     = NVL(TO_DATE(:fecha_fin,'YYYY-MM-DD'), FECHA_FIN),
           CANTIDAD_REAL = NVL(:cantidad_real, CANTIDAD_REAL),
           OBSERVACIONES = NVL(:observaciones, OBSERVACIONES)
       WHERE ID_ORDEN = :id`,
      {
        estado: estado || null,
        fecha_inicio: fecha_inicio || null,
        fecha_fin: fecha_fin || null,
        cantidad_real: cantidad_real || null,
        observaciones: observaciones || null,
        id: req.params.id
      }
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Orden de producción no encontrada' });
    res.json({ success: true, message: 'Orden de producción actualizada' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const remove = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `DELETE FROM ORDEN_PRODUCCION WHERE ID_ORDEN = :id`,
      [req.params.id]
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Orden de producción no encontrada' });
    res.json({ success: true, message: 'Orden de producción eliminada' });
  } catch (err) {
    if (err.errorNum === 2292)
      return res.status(409).json({ success: false, message: 'No se puede eliminar: tiene consumos o movimientos relacionados' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

module.exports = { getAll, getById, create, update, remove };
