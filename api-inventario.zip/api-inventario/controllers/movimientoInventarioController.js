const { getConnection, closeConnection } = require('../config/db');
const oracledb = require('oracledb');

const getAll = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT MI.ID_MOVIMIENTO, MI.COD_ARTICULO,
              MI.ID_TIPO_MOV, TM.DESCRIPCION AS TIPO_MOVIMIENTO, TM.NATURALEZA,
              MI.ID_ORDEN, OP.NUMERO_ORDEN,
              TO_CHAR(MI.FECHA_MOV,'YYYY-MM-DD') AS FECHA_MOV,
              MI.CANTIDAD, MI.COSTO_UNITARIO,
              MI.REFERENCIA, MI.USUARIO, MI.OBSERVACIONES
       FROM MOVIMIENTO_INVENTARIO MI
       JOIN TIPO_MOVIMIENTO TM ON TM.ID_TIPO_MOV = MI.ID_TIPO_MOV
       LEFT JOIN ORDEN_PRODUCCION OP ON OP.ID_ORDEN = MI.ID_ORDEN
       ORDER BY MI.ID_MOVIMIENTO DESC`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const getById = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT MI.ID_MOVIMIENTO, MI.COD_ARTICULO,
              MI.ID_TIPO_MOV, TM.DESCRIPCION AS TIPO_MOVIMIENTO, TM.NATURALEZA,
              MI.ID_ORDEN, OP.NUMERO_ORDEN,
              TO_CHAR(MI.FECHA_MOV,'YYYY-MM-DD') AS FECHA_MOV,
              MI.CANTIDAD, MI.COSTO_UNITARIO,
              MI.REFERENCIA, MI.USUARIO, MI.OBSERVACIONES
       FROM MOVIMIENTO_INVENTARIO MI
       JOIN TIPO_MOVIMIENTO TM ON TM.ID_TIPO_MOV = MI.ID_TIPO_MOV
       LEFT JOIN ORDEN_PRODUCCION OP ON OP.ID_ORDEN = MI.ID_ORDEN
       WHERE MI.ID_MOVIMIENTO = :id`,
      [req.params.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Movimiento no encontrado' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

// GET movimientos por artículo
const getByArticulo = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT MI.ID_MOVIMIENTO, TM.DESCRIPCION AS TIPO_MOVIMIENTO, TM.NATURALEZA,
              TO_CHAR(MI.FECHA_MOV,'YYYY-MM-DD') AS FECHA_MOV,
              MI.CANTIDAD, MI.COSTO_UNITARIO, MI.REFERENCIA, MI.USUARIO
       FROM MOVIMIENTO_INVENTARIO MI
       JOIN TIPO_MOVIMIENTO TM ON TM.ID_TIPO_MOV = MI.ID_TIPO_MOV
       WHERE MI.COD_ARTICULO = :cod
       ORDER BY MI.FECHA_MOV DESC`,
      [req.params.cod_articulo]
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const create = async (req, res) => {
  let conn;
  const { id_tipo_mov, id_orden, cod_articulo, fecha_mov, cantidad, costo_unitario, referencia, usuario, observaciones } = req.body;
  if (!id_tipo_mov || !cod_articulo || !cantidad || !usuario)
    return res.status(400).json({ success: false, message: 'id_tipo_mov, cod_articulo, cantidad y usuario son requeridos' });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO MOVIMIENTO_INVENTARIO
         (ID_TIPO_MOV, ID_ORDEN, COD_ARTICULO, FECHA_MOV, CANTIDAD, COSTO_UNITARIO, REFERENCIA, USUARIO, OBSERVACIONES)
       VALUES
         (:id_tipo_mov, :id_orden, :cod_articulo,
          NVL(TO_DATE(:fecha_mov,'YYYY-MM-DD'), SYSDATE),
          :cantidad, :costo_unitario, :referencia, :usuario, :observaciones)
       RETURNING ID_MOVIMIENTO INTO :id`,
      {
        id_tipo_mov, id_orden: id_orden || null, cod_articulo,
        fecha_mov: fecha_mov || null,
        cantidad, costo_unitario: costo_unitario || null,
        referencia: referencia || null, usuario,
        observaciones: observaciones || null,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }
    );
    res.status(201).json({ success: true, message: 'Movimiento registrado', id: result.outBinds.id[0] });
  } catch (err) {
    if (err.errorNum === 2291)
      return res.status(400).json({ success: false, message: 'Tipo de movimiento u orden de producción no existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const update = async (req, res) => {
  let conn;
  const { referencia, costo_unitario, observaciones } = req.body;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `UPDATE MOVIMIENTO_INVENTARIO
       SET REFERENCIA     = NVL(:referencia, REFERENCIA),
           COSTO_UNITARIO = NVL(:costo_unitario, COSTO_UNITARIO),
           OBSERVACIONES  = NVL(:observaciones, OBSERVACIONES)
       WHERE ID_MOVIMIENTO = :id`,
      { referencia, costo_unitario, observaciones, id: req.params.id }
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Movimiento no encontrado' });
    res.json({ success: true, message: 'Movimiento actualizado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const remove = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `DELETE FROM MOVIMIENTO_INVENTARIO WHERE ID_MOVIMIENTO = :id`,
      [req.params.id]
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Movimiento no encontrado' });
    res.json({ success: true, message: 'Movimiento eliminado' });
  } catch (err) {
    if (err.errorNum === 2292)
      return res.status(409).json({ success: false, message: 'No se puede eliminar: tiene consumos relacionados' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

module.exports = { getAll, getById, getByArticulo, create, update, remove };
