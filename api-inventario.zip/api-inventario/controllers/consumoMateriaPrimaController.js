const { getConnection, closeConnection } = require('../config/db');
const oracledb = require('oracledb');

const getAll = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT CM.ID_CONSUMO, CM.COD_ARTICULO,
              CM.ID_ORDEN, OP.NUMERO_ORDEN,
              CM.CANTIDAD_PLAN, CM.CANTIDAD_REAL,
              TO_CHAR(CM.FECHA_CONSUMO,'YYYY-MM-DD') AS FECHA_CONSUMO,
              CM.ID_MOVIMIENTO, CM.OBSERVACIONES
       FROM CONSUMO_MATERIA_PRIMA CM
       JOIN ORDEN_PRODUCCION OP ON OP.ID_ORDEN = CM.ID_ORDEN
       ORDER BY CM.ID_CONSUMO DESC`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

// GET consumos por orden de producción
const getByOrden = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT CM.ID_CONSUMO, CM.COD_ARTICULO,
              CM.CANTIDAD_PLAN, CM.CANTIDAD_REAL,
              TO_CHAR(CM.FECHA_CONSUMO,'YYYY-MM-DD') AS FECHA_CONSUMO,
              CM.ID_MOVIMIENTO, CM.OBSERVACIONES
       FROM CONSUMO_MATERIA_PRIMA CM
       WHERE CM.ID_ORDEN = :id_orden
       ORDER BY CM.ID_CONSUMO`,
      [req.params.id_orden]
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const getById = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT CM.ID_CONSUMO, CM.COD_ARTICULO,
              CM.ID_ORDEN, OP.NUMERO_ORDEN,
              CM.CANTIDAD_PLAN, CM.CANTIDAD_REAL,
              TO_CHAR(CM.FECHA_CONSUMO,'YYYY-MM-DD') AS FECHA_CONSUMO,
              CM.ID_MOVIMIENTO, CM.OBSERVACIONES
       FROM CONSUMO_MATERIA_PRIMA CM
       JOIN ORDEN_PRODUCCION OP ON OP.ID_ORDEN = CM.ID_ORDEN
       WHERE CM.ID_CONSUMO = :id`,
      [req.params.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Consumo no encontrado' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const create = async (req, res) => {
  let conn;
  const { id_orden, cod_articulo, cantidad_plan, cantidad_real = 0, fecha_consumo, id_movimiento, observaciones } = req.body;
  if (!id_orden || !cod_articulo || !cantidad_plan)
    return res.status(400).json({ success: false, message: 'id_orden, cod_articulo y cantidad_plan son requeridos' });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO CONSUMO_MATERIA_PRIMA
         (ID_ORDEN, COD_ARTICULO, CANTIDAD_PLAN, CANTIDAD_REAL, FECHA_CONSUMO, ID_MOVIMIENTO, OBSERVACIONES)
       VALUES
         (:id_orden, :cod_articulo, :cantidad_plan, :cantidad_real,
          NVL(TO_DATE(:fecha_consumo,'YYYY-MM-DD'), SYSDATE),
          :id_movimiento, :observaciones)
       RETURNING ID_CONSUMO INTO :id`,
      {
        id_orden, cod_articulo, cantidad_plan, cantidad_real,
        fecha_consumo: fecha_consumo || null,
        id_movimiento: id_movimiento || null,
        observaciones: observaciones || null,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }
    );
    res.status(201).json({ success: true, message: 'Consumo registrado', id: result.outBinds.id[0] });
  } catch (err) {
    if (err.errorNum === 2291)
      return res.status(400).json({ success: false, message: 'Orden de producción o movimiento no existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const update = async (req, res) => {
  let conn;
  const { cantidad_real, id_movimiento, observaciones } = req.body;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `UPDATE CONSUMO_MATERIA_PRIMA
       SET CANTIDAD_REAL = NVL(:cantidad_real, CANTIDAD_REAL),
           ID_MOVIMIENTO = NVL(:id_movimiento, ID_MOVIMIENTO),
           OBSERVACIONES = NVL(:observaciones, OBSERVACIONES)
       WHERE ID_CONSUMO = :id`,
      { cantidad_real, id_movimiento, observaciones, id: req.params.id }
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Consumo no encontrado' });
    res.json({ success: true, message: 'Consumo actualizado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const remove = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `DELETE FROM CONSUMO_MATERIA_PRIMA WHERE ID_CONSUMO = :id`,
      [req.params.id]
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Consumo no encontrado' });
    res.json({ success: true, message: 'Consumo eliminado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

module.exports = { getAll, getById, getByOrden, create, update, remove };
