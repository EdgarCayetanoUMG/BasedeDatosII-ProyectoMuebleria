const { getConnection, closeConnection } = require('../config/db');
const oracledb = require('oracledb');

const getAll = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT LM.ID_LISTA, LM.CODIGO, LM.DESCRIPCION, LM.VERSION, LM.ACTIVO,
              LM.ID_CENTRO, CT.NOMBRE AS CENTRO_TRABAJO,
              TO_CHAR(LM.FECHA_CREACION,'YYYY-MM-DD') AS FECHA_CREACION
       FROM LISTA_MATERIALES LM
       JOIN CENTRO_TRABAJO CT ON CT.ID_CENTRO = LM.ID_CENTRO
       ORDER BY LM.ID_LISTA`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const getById = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT LM.ID_LISTA, LM.CODIGO, LM.DESCRIPCION, LM.VERSION, LM.ACTIVO,
              LM.ID_CENTRO, CT.NOMBRE AS CENTRO_TRABAJO,
              TO_CHAR(LM.FECHA_CREACION,'YYYY-MM-DD') AS FECHA_CREACION
       FROM LISTA_MATERIALES LM
       JOIN CENTRO_TRABAJO CT ON CT.ID_CENTRO = LM.ID_CENTRO
       WHERE LM.ID_LISTA = :id`,
      [req.params.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Lista de materiales no encontrada' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const create = async (req, res) => {
  let conn;
  const { codigo, descripcion, id_centro, version = '1.0', activo = 1 } = req.body;
  if (!codigo || !descripcion || !id_centro)
    return res.status(400).json({ success: false, message: 'codigo, descripcion e id_centro son requeridos' });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO LISTA_MATERIALES (CODIGO, DESCRIPCION, ID_CENTRO, VERSION, ACTIVO)
       VALUES (:codigo, :descripcion, :id_centro, :version, :activo)
       RETURNING ID_LISTA INTO :id`,
      {
        codigo, descripcion, id_centro, version, activo,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }
    );
    res.status(201).json({ success: true, message: 'Lista de materiales creada', id: result.outBinds.id[0] });
  } catch (err) {
    if (err.errorNum === 1)
      return res.status(409).json({ success: false, message: 'El código ya existe' });
    if (err.errorNum === 2291)
      return res.status(400).json({ success: false, message: 'Centro de trabajo no existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const update = async (req, res) => {
  let conn;
  const { descripcion, id_centro, version, activo } = req.body;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `UPDATE LISTA_MATERIALES
       SET DESCRIPCION = NVL(:descripcion, DESCRIPCION),
           ID_CENTRO   = NVL(:id_centro, ID_CENTRO),
           VERSION     = NVL(:version, VERSION),
           ACTIVO      = NVL(:activo, ACTIVO)
       WHERE ID_LISTA = :id`,
      { descripcion, id_centro, version, activo, id: req.params.id }
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Lista de materiales no encontrada' });
    res.json({ success: true, message: 'Lista de materiales actualizada' });
  } catch (err) {
    if (err.errorNum === 2291)
      return res.status(400).json({ success: false, message: 'Centro de trabajo no existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const remove = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `DELETE FROM LISTA_MATERIALES WHERE ID_LISTA = :id`,
      [req.params.id]
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Lista de materiales no encontrada' });
    res.json({ success: true, message: 'Lista de materiales eliminada' });
  } catch (err) {
    if (err.errorNum === 2292)
      return res.status(409).json({ success: false, message: 'No se puede eliminar: tiene registros relacionados' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

module.exports = { getAll, getById, create, update, remove };
