const { getConnection, closeConnection } = require('../config/db');
const oracledb = require('oracledb');

const getAll = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT BD.ID_BOM_DET, BD.ID_LISTA, LM.DESCRIPCION AS LISTA_MATERIALES,
              BD.COD_ARTICULO, BD.CANTIDAD, BD.UNIDAD_MEDIDA,
              BD.DESPERDICIO_PCT, BD.OBSERVACIONES
       FROM BOM_DETALLE BD
       JOIN LISTA_MATERIALES LM ON LM.ID_LISTA = BD.ID_LISTA
       ORDER BY BD.ID_LISTA, BD.ID_BOM_DET`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

// GET detalle por lista
const getByLista = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT BD.ID_BOM_DET, BD.ID_LISTA, BD.COD_ARTICULO,
              BD.CANTIDAD, BD.UNIDAD_MEDIDA, BD.DESPERDICIO_PCT, BD.OBSERVACIONES
       FROM BOM_DETALLE BD
       WHERE BD.ID_LISTA = :id_lista
       ORDER BY BD.ID_BOM_DET`,
      [req.params.id_lista]
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const getById = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT BD.ID_BOM_DET, BD.ID_LISTA, LM.DESCRIPCION AS LISTA_MATERIALES,
              BD.COD_ARTICULO, BD.CANTIDAD, BD.UNIDAD_MEDIDA,
              BD.DESPERDICIO_PCT, BD.OBSERVACIONES
       FROM BOM_DETALLE BD
       JOIN LISTA_MATERIALES LM ON LM.ID_LISTA = BD.ID_LISTA
       WHERE BD.ID_BOM_DET = :id`,
      [req.params.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'BOM detalle no encontrado' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const create = async (req, res) => {
  let conn;
  const { id_lista, cod_articulo, cantidad, unidad_medida, desperdicio_pct = 0, observaciones } = req.body;
  if (!id_lista || !cod_articulo || !cantidad || !unidad_medida)
    return res.status(400).json({ success: false, message: 'id_lista, cod_articulo, cantidad y unidad_medida son requeridos' });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO BOM_DETALLE (ID_LISTA, COD_ARTICULO, CANTIDAD, UNIDAD_MEDIDA, DESPERDICIO_PCT, OBSERVACIONES)
       VALUES (:id_lista, :cod_articulo, :cantidad, :unidad_medida, :desperdicio_pct, :observaciones)
       RETURNING ID_BOM_DET INTO :id`,
      {
        id_lista, cod_articulo, cantidad, unidad_medida,
        desperdicio_pct, observaciones: observaciones || null,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }
    );
    res.status(201).json({ success: true, message: 'BOM detalle creado', id: result.outBinds.id[0] });
  } catch (err) {
    if (err.errorNum === 2291)
      return res.status(400).json({ success: false, message: 'Lista de materiales no existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const update = async (req, res) => {
  let conn;
  const { cantidad, unidad_medida, desperdicio_pct, observaciones } = req.body;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `UPDATE BOM_DETALLE
       SET CANTIDAD        = NVL(:cantidad, CANTIDAD),
           UNIDAD_MEDIDA   = NVL(:unidad_medida, UNIDAD_MEDIDA),
           DESPERDICIO_PCT = NVL(:desperdicio_pct, DESPERDICIO_PCT),
           OBSERVACIONES   = NVL(:observaciones, OBSERVACIONES)
       WHERE ID_BOM_DET = :id`,
      { cantidad, unidad_medida, desperdicio_pct, observaciones, id: req.params.id }
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'BOM detalle no encontrado' });
    res.json({ success: true, message: 'BOM detalle actualizado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const remove = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `DELETE FROM BOM_DETALLE WHERE ID_BOM_DET = :id`,
      [req.params.id]
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'BOM detalle no encontrado' });
    res.json({ success: true, message: 'BOM detalle eliminado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

module.exports = { getAll, getById, getByLista, create, update, remove };
