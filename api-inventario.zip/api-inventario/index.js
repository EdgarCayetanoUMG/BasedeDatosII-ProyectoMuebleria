require('dotenv').config();
const express = require('express');
const cors    = require('cors');

const inventarioRoutes = require('./routes/inventario');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ───────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Health check ─────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    api: 'Módulo de Inventario',
    version: '1.0.0',
    responsable: 'Edgar Cayetano',
    status: 'OK'
  });
});

// ── Rutas ────────────────────────────────────────────────────
app.use('/api/inventario', inventarioRoutes);

// ── 404 ──────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Ruta no encontrada' });
});

// ── Error handler ─────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Error interno del servidor' });
});

// ── Start ─────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ API Inventario corriendo en http://localhost:${PORT}`);
});
