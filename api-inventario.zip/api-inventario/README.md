# API REST — Módulo de Inventario
**Responsable:** Edgar Cayetano  
**Stack:** Node.js + Express + Oracle DB  
**Base URL:** `http://localhost:3000/api/inventario`

---

## Configuración inicial

1. Instalar dependencias:
```bash
npm install
```

2. Crear archivo `.env` (copiar desde `.env.example`):
```
DB_USER=system
DB_PASSWORD=tu_password
DB_CONNECTION_STRING=localhost:1521/XE
PORT=3000
```

3. Ejecutar el DDL en Oracle SQL Developer (`schema.sql`)

4. Iniciar el servidor:
```bash
npm run dev   # desarrollo
npm start     # producción
```

---

## Endpoints

### TIPO_MOVIMIENTO
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET    | `/tipo-movimiento` | Listar todos |
| GET    | `/tipo-movimiento/:id` | Obtener por ID |
| POST   | `/tipo-movimiento` | Crear |
| PUT    | `/tipo-movimiento/:id` | Actualizar |
| DELETE | `/tipo-movimiento/:id` | Eliminar |

**Body POST/PUT:**
```json
{
  "codigo": "ENT001",
  "descripcion": "Entrada por compra",
  "naturaleza": "E",
  "activo": 1
}
```
> `naturaleza`: `"E"` = Entrada, `"S"` = Salida

---

### CENTRO_TRABAJO
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET    | `/centro-trabajo` | Listar todos |
| GET    | `/centro-trabajo/:id` | Obtener por ID |
| POST   | `/centro-trabajo` | Crear |
| PUT    | `/centro-trabajo/:id` | Actualizar |
| DELETE | `/centro-trabajo/:id` | Eliminar |

**Body POST/PUT:**
```json
{
  "codigo": "CT001",
  "nombre": "Línea de Ensamble A",
  "descripcion": "Centro principal de ensamble",
  "capacidad": 500.00,
  "activo": 1
}
```

---

### LISTA_MATERIALES
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET    | `/lista-materiales` | Listar todas |
| GET    | `/lista-materiales/:id` | Obtener por ID |
| POST   | `/lista-materiales` | Crear |
| PUT    | `/lista-materiales/:id` | Actualizar |
| DELETE | `/lista-materiales/:id` | Eliminar |

**Body POST/PUT:**
```json
{
  "codigo": "BOM-001",
  "descripcion": "BOM Producto Principal v1",
  "id_centro": 1,
  "version": "1.0",
  "activo": 1
}
```

---

### BOM_DETALLE
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET    | `/bom-detalle` | Listar todos |
| GET    | `/bom-detalle/:id` | Obtener por ID |
| GET    | `/bom-detalle/por-lista/:id_lista` | Detalles de una lista |
| POST   | `/bom-detalle` | Crear |
| PUT    | `/bom-detalle/:id` | Actualizar |
| DELETE | `/bom-detalle/:id` | Eliminar |

**Body POST/PUT:**
```json
{
  "id_lista": 1,
  "cod_articulo": "ART-001",
  "cantidad": 2.5,
  "unidad_medida": "KG",
  "desperdicio_pct": 5.00,
  "observaciones": "Material principal"
}
```

---

### ORDEN_PRODUCCION
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET    | `/orden-produccion` | Listar todas |
| GET    | `/orden-produccion/:id` | Obtener por ID |
| POST   | `/orden-produccion` | Crear |
| PUT    | `/orden-produccion/:id` | Actualizar estado/avance |
| DELETE | `/orden-produccion/:id` | Eliminar |

**Body POST:**
```json
{
  "numero_orden": "OP-2025-001",
  "id_lista": 1,
  "id_centro": 1,
  "fecha_inicio": "2025-05-01",
  "fecha_fin": "2025-05-15",
  "cantidad_planif": 100,
  "observaciones": "Primera orden del mes"
}
```
**Body PUT (actualizar avance):**
```json
{
  "estado": "EN_PROCESO",
  "cantidad_real": 45,
  "fecha_inicio": "2025-05-02"
}
```
> `estado` válidos: `PENDIENTE`, `EN_PROCESO`, `COMPLETADA`, `CANCELADA`

---

### MOVIMIENTO_INVENTARIO
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET    | `/movimiento-inventario` | Listar todos |
| GET    | `/movimiento-inventario/:id` | Obtener por ID |
| GET    | `/movimiento-inventario/por-articulo/:cod_articulo` | Por artículo |
| POST   | `/movimiento-inventario` | Registrar movimiento |
| PUT    | `/movimiento-inventario/:id` | Actualizar |
| DELETE | `/movimiento-inventario/:id` | Eliminar |

**Body POST:**
```json
{
  "id_tipo_mov": 1,
  "id_orden": 1,
  "cod_articulo": "ART-001",
  "fecha_mov": "2025-05-04",
  "cantidad": 50,
  "costo_unitario": 25.50,
  "referencia": "OP-2025-001",
  "usuario": "edgar.cayetano",
  "observaciones": "Consumo según orden"
}
```

---

### CONSUMO_MATERIA_PRIMA
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET    | `/consumo-materia-prima` | Listar todos |
| GET    | `/consumo-materia-prima/:id` | Obtener por ID |
| GET    | `/consumo-materia-prima/por-orden/:id_orden` | Por orden |
| POST   | `/consumo-materia-prima` | Registrar consumo |
| PUT    | `/consumo-materia-prima/:id` | Actualizar cantidad real |
| DELETE | `/consumo-materia-prima/:id` | Eliminar |

**Body POST:**
```json
{
  "id_orden": 1,
  "cod_articulo": "ART-001",
  "cantidad_plan": 10,
  "cantidad_real": 9.5,
  "fecha_consumo": "2025-05-04",
  "id_movimiento": 1,
  "observaciones": "Consumo real registrado"
}
```

---

## Códigos de respuesta
| Código | Significado |
|--------|-------------|
| 200 | OK |
| 201 | Creado exitosamente |
| 400 | Datos inválidos o FK inexistente |
| 404 | Registro no encontrado |
| 409 | Conflicto (código duplicado o FK activa) |
| 500 | Error interno del servidor |
