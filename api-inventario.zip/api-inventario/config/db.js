const oracledb = require('oracledb');
require('dotenv').config();

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.autoCommit = true;

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  connectionString: process.env.DB_CONNECTION_STRING,
};

async function getConnection() {
  return await oracledb.getConnection(dbConfig);
}

async function closeConnection(conn) {
  if (conn) {
    try {
      await conn.close();
    } catch (err) {
      console.error('Error cerrando conexión:', err);
    }
  }
}

module.exports = { getConnection, closeConnection };
