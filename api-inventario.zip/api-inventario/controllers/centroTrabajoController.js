const { getConnection, closeConnection } = require('../config/db');
const oracledb = require('oracledb');

const getAll = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT ID_CENTRO, CODIGO, NOMBRE, DESCRIPCION, CAPACIDAD, ACTIVO,
              TO_CHAR(FECHA_CREACION,'YYYY-MM-DD') AS FECHA_CREACION
       FROM CENTRO_TRABAJO ORDER BY ID_CENTRO`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const getById = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `SELECT ID_CENTRO, CODIGO, NOMBRE, DESCRIPCION, CAPACIDAD, ACTIVO,
              TO_CHAR(FECHA_CREACION,'YYYY-MM-DD') AS FECHA_CREACION
       FROM CENTRO_TRABAJO WHERE ID_CENTRO = :id`,
      [req.params.id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Centro de trabajo no encontrado' });
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const create = async (req, res) => {
  let conn;
  const { codigo, nombre, descripcion, capacidad, activo = 1 } = req.body;
  if (!codigo || !nombre)
    return res.status(400).json({ success: false, message: 'codigo y nombre son requeridos' });
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `INSERT INTO CENTRO_TRABAJO (CODIGO, NOMBRE, DESCRIPCION, CAPACIDAD, ACTIVO)
       VALUES (:codigo, :nombre, :descripcion, :capacidad, :activo)
       RETURNING ID_CENTRO INTO :id`,
      {
        codigo, nombre, descripcion: descripcion || null, capacidad: capacidad || null, activo,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }
    );
    res.status(201).json({ success: true, message: 'Centro de trabajo creado', id: result.outBinds.id[0] });
  } catch (err) {
    if (err.errorNum === 1)
      return res.status(409).json({ success: false, message: 'El código ya existe' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const update = async (req, res) => {
  let conn;
  const { nombre, descripcion, capacidad, activo } = req.body;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `UPDATE CENTRO_TRABAJO
       SET NOMBRE      = NVL(:nombre, NOMBRE),
           DESCRIPCION = NVL(:descripcion, DESCRIPCION),
           CAPACIDAD   = NVL(:capacidad, CAPACIDAD),
           ACTIVO      = NVL(:activo, ACTIVO)
       WHERE ID_CENTRO = :id`,
      { nombre, descripcion, capacidad, activo, id: req.params.id }
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Centro de trabajo no encontrado' });
    res.json({ success: true, message: 'Centro de trabajo actualizado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

const remove = async (req, res) => {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(
      `DELETE FROM CENTRO_TRABAJO WHERE ID_CENTRO = :id`,
      [req.params.id]
    );
    if (result.rowsAffected === 0)
      return res.status(404).json({ success: false, message: 'Centro de trabajo no encontrado' });
    res.json({ success: true, message: 'Centro de trabajo eliminado' });
  } catch (err) {
    if (err.errorNum === 2292)
      return res.status(409).json({ success: false, message: 'No se puede eliminar: tiene registros relacionados' });
    res.status(500).json({ success: false, message: err.message });
  } finally {
    await closeConnection(conn);
  }
};

module.exports = { getAll, getById, create, update, remove };
